<template>
    <div class="choiceFood">
        <div class="title">
            <p>选择食品种类</p>
        </div>
    </div>
</template>


<script>
export default {
    
}
</script>

<style scoped>

</style>

