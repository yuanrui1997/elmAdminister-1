<template>
    <div id="dungunx">
      <h3>添加食品</h3>
    </div>
</template>

<script>
    export default {
        name: "elmaddfood05"
    }
</script>

<style scoped>
#dungunx h3{
  font-size: 16px;
  color: #000;
  font-weight: 100;
  text-align: center;
  padding:20px 0px
}
</style>
