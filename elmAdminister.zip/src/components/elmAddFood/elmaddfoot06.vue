<template>
  <div id="onrtun">
    <elmaddfoot05></elmaddfoot05>
    <elmaddfoot07></elmaddfoot07>
    <elmaddfoot08></elmaddfoot08>
    <elmaddfoot09></elmaddfoot09>
    <elmaddfoot10></elmaddfoot10>
    <elmaddfoot11></elmaddfoot11>
    <elmaddfoot12></elmaddfoot12>
<!--    <elmaddfoot13></elmaddfoot13>-->
  </div>
</template>

<script>
  import elmaddfoot05 from'./elmaddfood05'
  import elmaddfoot07 from'./elmaddfoot07'
  import elmaddfoot08 from'./elmaddfoot08'
  import elmaddfoot09 from'./elmaddfoot09'
  import elmaddfoot10 from'./elmaddfoot10'
  import elmaddfoot11 from'./elmaddfoot11'
  import elmaddfoot12 from'./elmaddfoot12'
  // import elmaddfoot13 from'./elmaddfoot13'

    export default {
      components:{
        elmaddfoot05,
        elmaddfoot07,
        elmaddfoot08,
       elmaddfoot09,
        elmaddfoot10,
        elmaddfoot11,
        elmaddfoot12,
        // elmaddfoot13
      }
    }
</script>

<style scoped>
#onrtun{
  width: 930px;
  height: 100%;
  border: 1px solid #eaeefb;
  border-radius: 5px;
  margin: 0 auto;
  margin-top: 20px;
}
</style>
